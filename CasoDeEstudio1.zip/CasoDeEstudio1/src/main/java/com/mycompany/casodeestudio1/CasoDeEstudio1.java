/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.casodeestudio1;

/**
 *
 * @author jareg
 */
public class CasoDeEstudio1 {

    public static void main(String[] args) {
        
        javax.swing.SwingUtilities.invokeLater(()->{
            new Swing();
        });
    }
}
