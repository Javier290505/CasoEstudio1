/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.casodeestudio1;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author jareg
 */
public class Swing extends JFrame {
    
    private Inventario inventario;
    private JTable tablaLibros;
    private JTextField Titulo;
    private JTextField Autor;
    private JTextField Isbn;
    private JTextField Editorial;
    private JTextField Precio;
    private JTextField Stock;
    
    
    public Swing(){
        
        inventario = new Inventario();
        
        inicializarComponentes();
    }
    
    private void inicializarComponentes(){
        
        setTitle("Gestion de Inventario Libreria");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        JPanel panelDatos = new JPanel(new GridLayout(7,2));
        panelDatos.add(new JLabel("Título:"));
        Titulo = new JTextField();
        panelDatos.add(Titulo);

        panelDatos.add(new JLabel("Autor:"));
        Autor = new JTextField();
        panelDatos.add(Autor);

        panelDatos.add(new JLabel("ISBN:"));
        Isbn = new JTextField();
        panelDatos.add(Isbn);

        panelDatos.add(new JLabel("Editorial:"));
        Editorial = new JTextField();
        panelDatos.add(Editorial);

        panelDatos.add(new JLabel("Precio unitario:"));
        Precio = new JTextField();
        panelDatos.add(Precio);

        panelDatos.add(new JLabel("Cantidad stock:"));
        Stock = new JTextField();
        panelDatos.add(Stock);

        JButton botonAgregar = new JButton("Agregar libro");
        panelDatos.add(botonAgregar);
        
        tablaLibros = new JTable();
        JScrollPane scrollTabla = new JScrollPane(tablaLibros);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelDatos, BorderLayout.NORTH);
        getContentPane().add(scrollTabla, BorderLayout.CENTER);

        setVisible(true);
        
        botonAgregar.addActionListener(e -> agregarLibro());
    }
    
    private void agregarLibro(){
        
        try{
            String titulo = Titulo.getText();
            String autor = Autor.getText();
            String isbn = Isbn.getText();
            String editorial = Editorial.getText();
            Double precio = Double.valueOf(Precio.getText());
            Integer stock = Integer.valueOf(Stock.getText());
            
            Libro libro = new Libro(titulo, autor, isbn, editorial, precio, stock);
        inventario.agregarLibro(libro);
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Libro agregado correctamente");
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Precio y stock deben ser numéricos");
    }
}
    private void actualizarTabla() {
        String[] columnas = {"Título", "Autor", "ISBN", "Editorial", "Precio", "Cantidad"};
        ArrayList<Libro> libros = inventario.getLibros();
        Object[][] datos = new Object[libros.size()][6];
        for (int i = 0; i < libros.size(); i++) {
            Libro l = libros.get(i);
            datos[i][0] = l.getTitulo();
            datos[i][1] = l.getAutor();
            datos[i][2] = l.getIsbn();
            datos[i][3] = l.getEditorial();
            datos[i][4] = l.getPrecioConDescuento();
            datos[i][5] = l.getCantidadStock();
        }
        tablaLibros.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
    }
        }
    
            

