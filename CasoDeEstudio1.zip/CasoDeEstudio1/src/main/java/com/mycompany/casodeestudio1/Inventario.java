/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.casodeestudio1;

import java.io.*;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author jareg
 */
public class Inventario implements Serializable {
    
    private ArrayList<Libro> listaLibros;
    
    public Inventario(){
        
        listaLibros = new ArrayList<>();
    }
    
    public void agregarLibro(Libro libro){
        
        listaLibros.add(libro);
    }
    
    public ArrayList<Libro>getKibros(){
        
        return listaLibros;
    }
    
   public void guardarArchivos(String nombreArchivo) {
       
    try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(nombreArchivo))) {
        dos.writeInt(listaLibros.size());

        for (Libro l : listaLibros) {
            dos.writeUTF(l.getTitulo());
            dos.writeUTF(l.getAutor());
            dos.writeUTF(l.getIsbn());
            dos.writeUTF(l.getEditorial());
            dos.writeDouble(l.getPrecioUnidad());
            dos.writeInt(l.getCantidadStock());
        }
        System.out.println("Inventario guardado con DataOutputStream.");
    } catch (IOException e) {
        System.err.println("Error al guardar: " + e.getMessage());
    }
}
    
    public void cargarArchivo(String nombreArchivo) {
        listaLibros.clear();
        try (DataInputStream dis = new DataInputStream(new FileInputStream(nombreArchivo))) {
            int cantidad = dis.readInt(); // cantidad de libros
            for (int i = 0; i < cantidad; i++) {
                String titulo = dis.readUTF();
                String autor = dis.readUTF();
                String isbn = dis.readUTF();
                String editorial = dis.readUTF();
                double precio = dis.readDouble();
                int stock = dis.readInt();
                Libro l = new Libro(titulo, autor, isbn, editorial, precio, stock);
                listaLibros.add(l);
            }
            System.out.println("Inventario cargado con DataInputStream.");
        } catch (IOException e) {
            System.err.println("Error al cargar: " + e.getMessage());
        }
    }

    ArrayList<Libro> getLibros() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
            
        
    
    
    

