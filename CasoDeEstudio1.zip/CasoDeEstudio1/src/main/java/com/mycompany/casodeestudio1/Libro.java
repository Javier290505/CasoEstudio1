/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.casodeestudio1;

import java.io.Serializable;

/**
 *
 * @author jareg
 */
public class Libro implements Serializable {
    
    private String titulo;
    private String autor;
    private String isbn;
    private String editorial;
    private double precioUnidad;
    private int cantidadStock;

    public Libro(String titulo, String autor, String isbn, String editorial, double precioUnidad, int cantidadStock) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.editorial = editorial;
        this.precioUnidad = precioUnidad;
        this.cantidadStock = cantidadStock;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public double getPrecioUnidad() {
        return precioUnidad;
    }

    public void setPrecioUnidad(double precioUnidad) {
        this.precioUnidad = precioUnidad;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }
    
    public double getPrecioConDescuento(){
        
        if (cantidadStock > 10){
            return precioUnidad * 0.9;
        }
        return precioUnidad;
    }
    
    
    @Override
    public String toString(){
        
        return titulo + " - " + autor + "(" + isbn + ")";
    }
    
}
